#ifndef ACKERMANN_HPP_INCLUDED //guarda
#define ACKERMANN_HPP_INCLUDED //guarda

int ack(int m, int n); //prot�tipo da fun��o

#endif // ACKERMANN_HPP_INCLUDED
