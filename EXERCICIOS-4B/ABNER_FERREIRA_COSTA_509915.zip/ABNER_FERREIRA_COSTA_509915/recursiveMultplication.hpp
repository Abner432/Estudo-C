#ifndef RECURSIVEMULTPLICATION_HPP_INCLUDED //guarda
#define RECURSIVEMULTPLICATION_HPP_INCLUDED //guarda

int recursiveMultiplication (int num1,int num2); //prot�tipo da fun��o

#endif // RECURSIVEMULTPLICATION_HPP_INCLUDED
