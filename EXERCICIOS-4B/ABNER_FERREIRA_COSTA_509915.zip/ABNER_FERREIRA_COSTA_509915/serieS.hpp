#ifndef SERIES_HPP_INCLUDED //guarda
#define SERIES_HPP_INCLUDED //guarda

double serieS(int n); //prot�tipo da fun��o

#endif // SERIES_HPP_INCLUDED
