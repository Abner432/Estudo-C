#ifndef TETRANACCI_HPP_INCLUDED//guarda
#define TETRANACCI_HPP_INCLUDED//guarda

int tetra(int n); //prototipa a fun��o

#endif // TETRANACCI_HPP_INCLUDED
